package com.example.bimbybletest;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public class MainActivity extends Activity {

    private static final int REQ_BT = 101;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private BluetoothAdapter adapter;
    private BluetoothLeScanner scanner;
    private BluetoothGatt currentGatt;

    private Button scanButton;
    private Button stopButton;
    private TextView statusText;
    private TextView logText;
    private ListView listView;

    private final Map<String, ScanResult> results = new LinkedHashMap<>();
    private final ArrayList<String> rows = new ArrayList<>();
    private ArrayAdapter<String> listAdapter;
    private boolean scanning = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        BluetoothManager manager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        adapter = manager != null ? manager.getAdapter() : null;

        buildUi();

        if (adapter == null) {
            setStatus("Bluetooth wird auf diesem Gerät nicht unterstützt.");
            scanButton.setEnabled(false);
            return;
        }

        scanner = adapter.getBluetoothLeScanner();

        scanButton.setOnClickListener(v -> ensurePermissionsAndScan());
        stopButton.setOnClickListener(v -> stopScan());

        listView.setOnItemClickListener((parent, view, position, id) -> {
            if (position < 0 || position >= results.size()) return;
            ScanResult sr = new ArrayList<>(results.values()).get(position);
            connect(sr.getDevice());
        });

        appendLog("App bereit.");
        appendLog("Tippe auf „BLE-Geräte suchen“ und halte den TM7 in der Nähe.");
    }

    private void buildUi() {
        int pad = dp(16);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        root.setBackgroundColor(0xFFF4F7F8);

        TextView title = new TextView(this);
        title.setText("🥣 Bimby / Thermomix TM7 – BLE Test");
        title.setTextSize(22);
        title.setTextColor(0xFF142026);
        title.setPadding(0, 0, 0, dp(8));
        root.addView(title);

        TextView intro = new TextView(this);
        intro.setText("Native Bluetooth-LE-Suche. Gefundene Geräte antippen, um GATT-Dienste auszulesen.");
        intro.setTextSize(15);
        intro.setTextColor(0xFF607078);
        intro.setPadding(0, 0, 0, dp(12));
        root.addView(intro);

        scanButton = new Button(this);
        scanButton.setText("🔵 BLE-Geräte suchen");
        root.addView(scanButton);

        stopButton = new Button(this);
        stopButton.setText("Suche stoppen");
        stopButton.setEnabled(false);
        root.addView(stopButton);

        statusText = new TextView(this);
        statusText.setText("Noch nicht gestartet.");
        statusText.setTextSize(16);
        statusText.setTextColor(0xFF142026);
        statusText.setPadding(dp(8), dp(12), dp(8), dp(12));
        root.addView(statusText);

        TextView found = new TextView(this);
        found.setText("Gefundene Geräte – zum Verbinden antippen:");
        found.setTextSize(17);
        found.setTextColor(0xFF142026);
        found.setPadding(0, dp(8), 0, dp(6));
        root.addView(found);

        listView = new ListView(this);
        listAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, rows);
        listView.setAdapter(listAdapter);
        root.addView(listView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, dp(280)));

        TextView protocol = new TextView(this);
        protocol.setText("Test-Protokoll:");
        protocol.setTextSize(17);
        protocol.setTextColor(0xFF142026);
        protocol.setPadding(0, dp(12), 0, dp(6));
        root.addView(protocol);

        ScrollView scroll = new ScrollView(this);
        logText = new TextView(this);
        logText.setTextSize(13);
        logText.setTextColor(0xFFFFFFFF);
        logText.setBackgroundColor(0xFF111820);
        logText.setPadding(dp(10), dp(10), dp(10), dp(10));
        logText.setTextIsSelectable(true);
        scroll.addView(logText);
        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
    }

    private void ensurePermissionsAndScan() {
        if (!adapter.isEnabled()) {
            Toast.makeText(this, "Bitte Bluetooth einschalten.", Toast.LENGTH_LONG).show();
            return;
        }

        if (Build.VERSION.SDK_INT >= 31) {
            ArrayList<String> missing = new ArrayList<>();
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED)
                missing.add(Manifest.permission.BLUETOOTH_SCAN);
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)
                missing.add(Manifest.permission.BLUETOOTH_CONNECT);

            if (!missing.isEmpty()) {
                requestPermissions(missing.toArray(new String[0]), REQ_BT);
                return;
            }
        } else {
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQ_BT);
                return;
            }
        }

        startScan();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_BT) {
            boolean ok = true;
            for (int r : grantResults) {
                if (r != PackageManager.PERMISSION_GRANTED) ok = false;
            }
            if (ok) startScan();
            else setStatus("Bluetooth-Berechtigung wurde nicht erteilt.");
        }
    }

    @SuppressWarnings("MissingPermission")
    private void startScan() {
        if (scanner == null) scanner = adapter.getBluetoothLeScanner();
        if (scanner == null) {
            setStatus("BLE-Scanner nicht verfügbar.");
            return;
        }

        results.clear();
        rows.clear();
        listAdapter.notifyDataSetChanged();

        scanning = true;
        scanButton.setEnabled(false);
        stopButton.setEnabled(true);
        setStatus("Suche läuft … TM7 möglichst nahe ans Handy stellen.");
        appendLog("BLE-Scan gestartet.");

        scanner.startScan(scanCallback);
        handler.postDelayed(this::stopScan, 15000);
    }

    @SuppressWarnings("MissingPermission")
    private void stopScan() {
        if (!scanning) return;
        scanning = false;
        try { scanner.stopScan(scanCallback); } catch (Exception ignored) {}
        scanButton.setEnabled(true);
        stopButton.setEnabled(false);
        setStatus("Suche beendet. Gefunden: " + results.size());
        appendLog("BLE-Scan beendet. Geräte: " + results.size());
    }

    private final ScanCallback scanCallback = new ScanCallback() {
        @Override
        public void onScanResult(int callbackType, ScanResult result) {
            runOnUiThread(() -> addResult(result));
        }

        @Override
        public void onBatchScanResults(List<ScanResult> batchResults) {
            runOnUiThread(() -> {
                for (ScanResult r : batchResults) addResult(r);
            });
        }

        @Override
        public void onScanFailed(int errorCode) {
            runOnUiThread(() -> {
                setStatus("Scan-Fehler: " + errorCode);
                appendLog("Scan-Fehlercode: " + errorCode);
                scanButton.setEnabled(true);
                stopButton.setEnabled(false);
                scanning = false;
            });
        }
    };

    @SuppressWarnings("MissingPermission")
    private void addResult(ScanResult sr) {
        BluetoothDevice d = sr.getDevice();
        if (d == null) return;

        String address = d.getAddress();
        if (address == null) address = "(keine Adresse)";

        results.put(address, sr);
        rebuildRows();
    }

    @SuppressWarnings("MissingPermission")
    private void rebuildRows() {
        rows.clear();

        for (ScanResult sr : results.values()) {
            BluetoothDevice d = sr.getDevice();
            String name = "(kein Name)";
            try {
                String n = d.getName();
                if (n != null && !n.trim().isEmpty()) name = n;
            } catch (Exception ignored) {}

            ScanRecord rec = sr.getScanRecord();
            String advertisedName = rec != null ? rec.getDeviceName() : null;
            if ((name.equals("(kein Name)")) && advertisedName != null && !advertisedName.isEmpty())
                name = advertisedName;

            boolean interesting = isPossibleBimby(name, advertisedName);

            StringBuilder sb = new StringBuilder();
            if (interesting) sb.append("⭐ MÖGLICHER TM7 / BIMBY\n");
            sb.append(name)
              .append("\nAdresse: ").append(d.getAddress())
              .append("   RSSI: ").append(sr.getRssi()).append(" dBm");

            if (rec != null && rec.getServiceUuids() != null && !rec.getServiceUuids().isEmpty()) {
                sb.append("\nAdvertised Services: ");
                int count = 0;
                for (android.os.ParcelUuid p : rec.getServiceUuids()) {
                    if (count++ > 0) sb.append(", ");
                    sb.append(p.getUuid());
                }
            }

            rows.add(sb.toString());
        }
        listAdapter.notifyDataSetChanged();
    }

    private boolean isPossibleBimby(String... names) {
        for (String n : names) {
            if (n == null) continue;
            String s = n.toLowerCase(Locale.ROOT);
            if (s.contains("thermomix") || s.contains("bimby") || s.contains("vorwerk") ||
                    s.contains("tm7") || s.contains("tm 7")) return true;
        }
        return false;
    }

    @SuppressWarnings("MissingPermission")
    private void connect(BluetoothDevice device) {
        stopScan();

        if (currentGatt != null) {
            try { currentGatt.close(); } catch (Exception ignored) {}
            currentGatt = null;
        }

        String name = null;
        try { name = device.getName(); } catch (Exception ignored) {}
        appendLog("");
        appendLog("Verbinde mit: " + (name != null ? name : "(kein Name)") + " / " + device.getAddress());
        setStatus("Verbinde mit " + (name != null ? name : device.getAddress()) + " …");

        currentGatt = device.connectGatt(this, false, gattCallback, BluetoothDevice.TRANSPORT_LE);
    }

    private final BluetoothGattCallback gattCallback = new BluetoothGattCallback() {
        @Override
        public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState) {
            if (newState == BluetoothGatt.STATE_CONNECTED) {
                runOnUiThread(() -> {
                    setStatus("Verbunden. Lese GATT-Dienste …");
                    appendLog("GATT verbunden. Status: " + status);
                });
                try {
                    gatt.discoverServices();
                } catch (SecurityException e) {
                    runOnUiThread(() -> appendLog("Berechtigungsfehler: " + e.getMessage()));
                }
            } else if (newState == BluetoothGatt.STATE_DISCONNECTED) {
                runOnUiThread(() -> {
                    setStatus("Verbindung getrennt. Status: " + status);
                    appendLog("GATT getrennt. Status: " + status);
                });
                try { gatt.close(); } catch (Exception ignored) {}
            }
        }

        @Override
        public void onServicesDiscovered(BluetoothGatt gatt, int status) {
            runOnUiThread(() -> dumpServices(gatt, status));
        }
    };

    private void dumpServices(BluetoothGatt gatt, int status) {
        appendLog("Services entdeckt. Status: " + status);
        List<BluetoothGattService> services = gatt.getServices();

        if (services == null || services.isEmpty()) {
            appendLog("Keine GATT-Services sichtbar.");
            setStatus("Verbunden, aber keine Services sichtbar.");
            return;
        }

        appendLog("Anzahl GATT-Services: " + services.size());

        for (BluetoothGattService service : services) {
            appendLog("");
            appendLog("SERVICE " + service.getUuid());

            List<BluetoothGattCharacteristic> chars = service.getCharacteristics();
            if (chars == null || chars.isEmpty()) {
                appendLog("  (keine Characteristics)");
                continue;
            }

            for (BluetoothGattCharacteristic c : chars) {
                appendLog("  CHAR " + c.getUuid() + " [" + props(c.getProperties()) + "]");
            }
        }

        appendLog("");
        appendLog("FERTIG – bitte Screenshot vom Protokoll machen.");
        setStatus("GATT-Auslesung fertig. Screenshot vom Protokoll schicken.");
    }

    private String props(int p) {
        ArrayList<String> out = new ArrayList<>();
        if ((p & BluetoothGattCharacteristic.PROPERTY_READ) != 0) out.add("READ");
        if ((p & BluetoothGattCharacteristic.PROPERTY_WRITE) != 0) out.add("WRITE");
        if ((p & BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0) out.add("WRITE_NR");
        if ((p & BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0) out.add("NOTIFY");
        if ((p & BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0) out.add("INDICATE");
        if ((p & BluetoothGattCharacteristic.PROPERTY_BROADCAST) != 0) out.add("BROADCAST");
        return String.join(",", out);
    }

    private void setStatus(String s) {
        statusText.setText(s);
    }

    private void appendLog(String s) {
        String old = logText.getText().toString();
        logText.setText(old + (old.isEmpty() ? "" : "\n") + s);
    }

    private int dp(int x) {
        float d = getResources().getDisplayMetrics().density;
        return Math.round(x * d);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        stopScan();
        if (currentGatt != null) {
            try { currentGatt.close(); } catch (Exception ignored) {}
            currentGatt = null;
        }
    }
}
