BIMBY / THERMOMIX TM7 – BLE TEST

Zweck:
Diese Test-App scannt nativ nach Bluetooth-Low-Energy-Geräten.
Sie zeigt:
- Gerätename
- Bluetooth-Adresse (soweit Android sie freigibt)
- RSSI / Signalstärke
- beworbene Service-UUIDs
- nach Antippen: GATT-Services und Characteristics

Test:
1. Bluetooth am Handy einschalten.
2. TM7 einschalten und nahe ans Handy stellen.
3. App öffnen.
4. Bluetooth-Berechtigung erlauben.
5. "BLE-Geräte suchen" drücken.
6. Auffälliges Gerät antippen.
7. Nach "GATT-Auslesung fertig" einen Screenshot vom Protokoll machen.

Wichtig:
Ein gefundener Bluetooth-Dienst bedeutet noch nicht, dass der TM7
Gewicht, Zutaten oder Rezeptdaten für Drittanbieter-Apps freigibt.

Projekt:
- Java
- minSdk 26
- targetSdk 35
- keine Drittanbieter-Abhängigkeiten
